export class Config {
    public environment: string | null;
    public envConfig: {};

    public constructor() {
    }
}

