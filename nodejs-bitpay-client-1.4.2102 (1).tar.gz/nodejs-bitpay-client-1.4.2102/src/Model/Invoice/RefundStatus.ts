export const Pending = "pending";
export const Success = "success";
export const Failure = "failure";
