export interface SupportedTransactionCurrency {
    enabled: boolean;
    reason: string;
}
