export const New       = "new";
export const Paid      = "paid";
export const Confirmed = "confirmed";
export const Complete  = "complete";
export const Expired   = "expired";
export const Invalid   = "invalid";
