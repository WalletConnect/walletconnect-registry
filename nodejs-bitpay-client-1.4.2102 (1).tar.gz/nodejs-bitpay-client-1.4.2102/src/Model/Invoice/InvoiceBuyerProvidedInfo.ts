export interface InvoiceBuyerProvidedInfo {
    name: string;
    phoneNumber: string;
    selectedTransactionCurrency: string;
    emailAddress: string;
    selectedWallet: string;
}
