export interface Shopper {
    user: string;
}
