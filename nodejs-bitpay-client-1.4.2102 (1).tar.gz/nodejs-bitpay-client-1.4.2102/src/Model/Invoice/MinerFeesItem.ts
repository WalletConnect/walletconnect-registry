export interface MinerFeesItem {
    satoshisPerByte: bigint;
    totalFee: bigint;
}
