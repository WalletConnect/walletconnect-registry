export const INVITED = "invited";
export const UNVERIFIED = "unverified";
export const VERIFIED = "verified";
export const ACTIVE = "active";
export const PAUSED = "paused";
export const REMOVED = "removed";
