export const EMAIL = 1;
export const RECIPIENT_ID = 2;
export const SHOPPER_ID = 3;
