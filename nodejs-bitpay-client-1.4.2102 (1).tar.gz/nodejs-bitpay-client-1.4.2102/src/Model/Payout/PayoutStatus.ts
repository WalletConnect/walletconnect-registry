export const New = "new";
export const Funded = "funded";
export const Processing = "processing";
export const Complete = "complete";
export const Failed = "failed";
export const Cancelled = "cancelled";
export const Paid = "paid";
export const Unpaid = "unpaid";
