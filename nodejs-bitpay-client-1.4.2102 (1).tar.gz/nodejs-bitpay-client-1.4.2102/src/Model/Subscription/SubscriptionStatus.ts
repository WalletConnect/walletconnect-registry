export const Draft     = "draft";
export const Active    = "active";
export const Cancelled = "cancelled";
