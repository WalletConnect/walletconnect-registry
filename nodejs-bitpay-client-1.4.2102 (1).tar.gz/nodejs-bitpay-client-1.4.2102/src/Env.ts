export const Test: string = "TEST";
export const Prod: string = "PROD";
export const TestUrl: string = "https://test.bitpay.com/";
export const ProdUrl: string = "https://bitpay.com/";
export const BitpayApiVersion: string = "2.0.0";
export const BitpayPluginInfo: string = "BitPay_NodeJs_Client_v1.4.2102";
export const BitpayApiFrame: string = "custom";
export const BitpayApiFrameVersion: string = "2.0.0";
