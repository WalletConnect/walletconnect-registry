export class Facade {
    static Merchant = "merchant";
    static Payroll = "payroll";
}
